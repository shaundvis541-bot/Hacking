# Mobile Security Lab

A phone-friendly Android learning app with read-only diagnostics, a simulated in-app PIN challenge, and official Google/Motorola recovery links.

## Safety and limitations
- Does not bypass screen locks, Factory Reset Protection (FRP), Google account verification, anti-theft protections, or carrier/network locks.
- Standard apps cannot reliably read bootloader lock state or carrier unlock status.
- No data is collected or transmitted. Network links open only when tapped.

## Build APK on GitHub
1. Open the **Actions** tab in this repository.
2. Select **Build Android APK**.
3. Tap **Run workflow** (or push a commit to main).
4. Open the completed workflow run.
5. Under **Artifacts**, download **mobile-security-lab-debug-apk**.
6. Extract the ZIP and install app-debug.apk. Android may ask you to permit installs from your browser or file manager.

This creates a debug APK, not a Play Store release. Install only builds you trust.

## Build requirements
- JDK 17
- Gradle 8.9
- Android SDK platform 35
