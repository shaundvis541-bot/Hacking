package com.example.mobilesecuritylab

import android.app.Activity
import android.app.KeyguardManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(0xFF172033.toInt())
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(2), dp(7), dp(2), dp(7))
    }
    private fun action(s: String, run: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setOnClickListener { run() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
    }
    private fun page(title: String, subtitle: String) {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(24))
            setBackgroundColor(0xFFF4F7FB.toInt())
        }
        root.addView(label("MOBILE SECURITY LAB", 12f, true))
        root.addView(label(title, 27f, true)); root.addView(label(subtitle, 15f))
        scroll.addView(root); setContentView(scroll)
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); home() }
    private fun home() {
        page("Security, diagnostics & recovery", "A local learning tool. No root access or special permissions required.")
        root.addView(action("Device diagnostics") { diagnostics() })
        root.addView(action("Simulated lock challenge") { simulation() })
        root.addView(action("Recovery assistant") { recovery() })
        root.addView(label("Safety boundary", 18f, true))
        root.addView(label("This app does not unlock devices, remove FRP, bypass Google verification, or alter carrier locks. The lock challenge is only a toy simulation inside this app."))
        root.addView(label("Privacy: no network requests or data collection. Support links open only when tapped."))
    }
    private fun diagnostics() {
        page("Device diagnostics", "Read-only details available to an ordinary Android app.")
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        val patch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Build.VERSION.SECURITY_PATCH else "Not exposed"
        val rows = listOf(
            "Manufacturer" to Build.MANUFACTURER, "Brand" to Build.BRAND,
            "Model" to Build.MODEL, "Device" to Build.DEVICE,
            "Android version" to Build.VERSION.RELEASE, "SDK level" to Build.VERSION.SDK_INT.toString(),
            "Security patch" to patch, "Secure screen lock configured" to km.isDeviceSecure.toString(),
            "Keyguard currently locked" to km.isKeyguardLocked.toString(),
            "App ID" to packageName, "Checked" to DateFormat.getDateTimeInstance().format(Date())
        )
        rows.forEach { (k, v) -> root.addView(label(k, 13f, true)); root.addView(label(v)) }
        root.addView(label("Limitations", 18f, true))
        root.addView(label("Ordinary apps cannot reliably read bootloader lock state, SIM/carrier unlock status, or FRP/account-verification state. This app does not guess those values."))
        root.addView(action("Open Android settings") {
            runCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) }.onFailure { toast("Could not open Settings") }
        })
        root.addView(action("Back to home") { home() })
    }
    private fun simulation() {
        page("Simulated lock challenge", "Training only — this does not interact with Android's lock screen.")
        root.addView(label("Fictional app PIN: 2468. Try it, then try another value."))
        val entry = EditText(this).apply { hint = "Enter demo PIN"; inputType = 2; setSingleLine(true) }
        root.addView(entry)
        root.addView(action("Check demo PIN") {
            if (entry.text.toString() == "2468") {
                toast("Demo passed — only the simulation was unlocked.")
                root.addView(label("Simulated access granted. Real device security was not changed.", 16f, true))
            } else toast("Incorrect demo PIN. Try the documented demo value.")
        })
        root.addView(label("A real Android screen lock is enforced by the operating system and may be backed by hardware security and encryption. This exercise is deliberately separate from system authentication."))
        root.addView(action("Back to home") { home() })
    }
    private fun recovery() {
        page("Recovery assistant", "Use these official routes for a device or account you own or are authorized to manage.")
        root.addView(label("Before a factory reset", 18f, true))
        root.addView(label("A reset can erase local data and may still require a previously synced Google account. Back up data and confirm you know the account credentials first."))
        root.addView(action("Google Account recovery") { openUrl("https://accounts.google.com/signin/recovery") })
        root.addView(action("Google Android help") { openUrl("https://support.google.com/android/") })
        root.addView(action("Motorola support") { openUrl("https://en-us.support.motorola.com/") })
        root.addView(action("Google Find Hub") { openUrl("https://www.google.com/android/find/") })
        root.addView(action("Back to home") { home() })
    }
    private fun openUrl(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            .onFailure { toast("Unable to open link on this device") }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
